package com.Amazon.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import org.openqa.selenium.support.ui.Select;

import com.Amazon.Task.BaseClass;



public class AmazonHomepage extends BaseClass{

	public AmazonHomepage(WebDriver driver) {
		super(driver);
	
	}
	
	private By search= By.cssSelector("#searchDropdownBox");
	
	private By searchTextBox= By.cssSelector("#twotabsearchtextbox");
	
	private By searchButton= By.cssSelector(".nav-search-submit");
	
	private By bestSeller = By.cssSelector("[id$=best-seller]");
	
	private By acceptCookies = By.cssSelector("#sp-cc-accept");
	
	private By kindle = By.cssSelector(".s-desktop-content");
	
	private By paperback = By.cssSelector(".s-desktop-content");
	
	private By audibleAudioBooks = By.cssSelector(".s-desktop-content");
	
	private By rating = By.cssSelector(".s-desktop-content");
	
	public String getTitle(){
		waitForPageLoad();
		return driver.getTitle();
	}
	
	public void clickOnsearchDropdown(String book){
		waitForPageLoad();
		WebElement ele = driver.findElement(search);
		Select sel = new Select(ele);
		sel.selectByVisibleText(book);
	}
	
	public void EnterTextIntoSearchBox(String bookName){
		waitForPageLoad();
		driver.findElement(searchTextBox).sendKeys(bookName);
	}
	
	public void clickOnSearchButton(){
		waitForPageLoad();
		driver.findElement(searchButton).click();
	}
	
	public void AcceptCookies(){
		waitForPageLoad();
		driver.findElement(acceptCookies).click();
	}
	
	public  boolean userCheckTheBestSellerVisibility(String seller){
		waitForPageLoad();
		List<WebElement> ele=driver.findElements(bestSeller);
		for(WebElement ele2 :ele){
			if(ele2.getText().contains(seller));
			return true;
		}
		return false;
	}
	
	public boolean userCheckTheKindelVersionVisibility(String bookName,String version){
		waitForPageLoad();
		List<WebElement> ele=driver.findElements(kindle);
		for(WebElement ele2 :ele){
			if(ele2.getText().contains(bookName)){
				WebElement ele3 = ele2.findElement(By.cssSelector(".a-link-normal"));
				if(ele3.getText().contains(version));
				return true;
			}
		}
		return false;
	}
	
	public boolean userCheckThePaperbackVersionVisibility(String bookName,String version){
		waitForPageLoad();
		List<WebElement> ele=driver.findElements(paperback);
		for(WebElement ele2 :ele){
			if(ele2.getText().contains(bookName)){
				WebElement ele3 = ele2.findElement(By.cssSelector(".a-text-bold"));
				if(ele3.getText().contains(version));
				return true;
			}
		}
		return false;
	}
	
	public boolean userCheckTheAudibleAudioBooksVersionVisibility(String bookName,String version){
		waitForPageLoad();
		List<WebElement> ele=driver.findElements(audibleAudioBooks);
		for(WebElement ele2 :ele){
			if(ele2.getText().contains(bookName)){
				WebElement ele3 = ele2.findElement(By.cssSelector(".a-size-base.a-link-normal"));
				if(ele3.getText().contains(version));
				return true;
			}
		}
		return false;
	}
	
	public boolean userCheckTheRatingVisibility(String bookName,String version){
		waitForPageLoad();
		List<WebElement> ele=driver.findElements(rating);
		for(WebElement ele2 :ele){
			System.out.println(ele2.getText() + "Output...");
			if(ele2.getText().contains(bookName)){
				WebElement ele3 = ele2.findElement(By.cssSelector(".a-icon-star-small"));
				System.out.println(ele3.getText() + "Output...");
				if(ele3.getText().contains(version));
				return true;
			}
		}
		return false;
	}
}
