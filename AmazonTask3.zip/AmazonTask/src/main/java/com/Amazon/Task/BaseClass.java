package com.Amazon.Task;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {


		protected WebDriver driver;
		protected WebDriverWait wait;

		public BaseClass(WebDriver driver) {
			PageFactory.initElements(driver, this);
			wait = new WebDriverWait(driver, 30);
			this.driver = driver;
		}
		
		public void waitForPageLoad(){
			wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
			
		}
		
		public WebElement getParent(final WebElement webElement) {
		    return webElement.findElement(By.xpath(".."));
		}
	}
