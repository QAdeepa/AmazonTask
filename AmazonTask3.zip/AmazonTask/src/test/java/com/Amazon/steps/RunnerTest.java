package com.Amazon.steps;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;

@CucumberOptions(plugin = { "html:target/cucumber-html-report","json:target/cucumber.json","usage:target/cucumber-usage.json"
		
		}, 
features = {"src/test/resources/amazonTask","src/test/resources"}, 		
		
strict = true, 
dryRun = false, 
monochrome = true, 
snippets = SnippetType.CAMELCASE)

@RunWith(Cucumber.class)
public class RunnerTest {
public static void generateReport() {
}
}

	