package com.Amazon.steps;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.Amazon.pages.AmazonHomepage;
import com.Amazon.pages.AuthorPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepAmazonTask {
		
		WebDriver driver = null;
		AmazonHomepage amazonHomePage;
		AuthorPage authorPage;
		URL url = getClass().getResource("src/test/resource/assets/event.jpg");
	    
		@Before
		public void setup() {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			options.addArguments("--start-maximized");
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Sreedhar\\Desktop\\Testing\\chromedriver_win32\\chromedriver.exe");

			driver = new ChromeDriver(options);
			amazonHomePage = new AmazonHomepage(driver);
			authorPage = new AuthorPage(driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.navigate().to("https://www.amazon.co.uk/");
			
		}
		@After
		public void cleanup() {
			 driver.quit();
		}
		
		@Given("^use navigate to search box in amazon website$")
		public void useNavigateToSearchBoxInAmazonWebsite() throws Throwable {
			 amazonHomePage.AcceptCookies();
			 amazonHomePage.clickOnsearchDropdown("Books");
			 
		}

		@When("^the user search Harry Potter book$")
		public void theUserSearchHarryPotterBook() throws Throwable {
			amazonHomePage.EnterTextIntoSearchBox("Harry Potter and the Philosopher's Stone");
		    amazonHomePage.clickOnSearchButton();
		}
		
		@When("^the user search for Author$")
		public void the_user_search_for_Author() throws Throwable {
			amazonHomePage.EnterTextIntoSearchBox("J.K. Rowling");
		    amazonHomePage.clickOnSearchButton();
		}

		@Then("^the user verify Harry Potter book is best seller$")
		public void theUserVerifyHarryPotterBookIsBestSeller() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheBestSellerVisibility("Best Seller"));
		}
		
		@Then("^the user verify Harry Potter book is available in Kindle Edition$")
		public void the_user_verify_Harry_Potter_book_is_available_in_Kindle_Edition() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheKindelVersionVisibility("Harry Potter and the Philosopher's Stone:","Kindle Edition"));
		}

		@Then("^the user verify Harry Potter book is available in Paperback Edition$")
		public void the_user_verify_Harry_Potter_book_is_available_in_Paperback_Edition() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckThePaperbackVersionVisibility("Harry Potter and the Philosopher's Stone:","Paperback Edition"));
		}
		
		@Then("^the user verify Harry Potter book is available in Audible Audiobooks Edition$")
		public void the_user_verify_Harry_Potter_book_is_available_in_Audible_Audiobooks_Edition() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheAudibleAudioBooksVersionVisibility("Harry Potter and the Philosopher's Stone:","Audible Audiobooks Edition"));
		}
		
		@Then("^the user verify Harry Potter book is having rating$")
		public void the_user_verify_Harry_Potter_book_is_having_rating() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheRatingVisibility("Harry Potter and the Philosopher's Stone:","Rating"));
		}

		@Then("^the user verify related books from the author$")
		public void the_user_verify_related_books_from_the_author() throws Throwable {
			Assert.assertTrue(authorPage.userCheckTheOtherBookOneVisibility("J.K. Rowling","The Ickabog: A warm and witty fairy-tale adventure to entertain the whole family"));
			Assert.assertTrue(authorPage.userCheckTheOtherBookTwoVisibility("J.K. Rowling","Harry Potter and the Chamber of Secrets, Book 2"));
		}
	}
