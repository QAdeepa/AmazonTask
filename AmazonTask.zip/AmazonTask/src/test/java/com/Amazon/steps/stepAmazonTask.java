package com.Amazon.steps;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.Amazon.pages.AmazonHomepage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepAmazonTask {
		
		WebDriver driver = null;
		AmazonHomepage amazonHomePage;
		URL url = getClass().getResource("src/test/resource/assets/event.jpg");
	    
		@Before
		public void setup() {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			options.addArguments("--start-maximized");
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Sreedhar\\Desktop\\Testing\\chromedriver_win32\\chromedriver.exe");

			driver = new ChromeDriver(options);
			amazonHomePage = new AmazonHomepage(driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.navigate().to("https://www.amazon.co.uk/");
			
		}
		@After
		public void cleanup() {
			 driver.quit();
		}
		
		@Given("^use navigate to search box in amazon website$")
		public void useNavigateToSearchBoxInAmazonWebsite() throws Throwable {
			 amazonHomePage.AcceptCookies();
			 amazonHomePage.clickOnsearchDropdown("Books");
			 
		}

		@When("^the user search Harry Potter book$")
		public void theUserSearchHarryPotterBook() throws Throwable {
			amazonHomePage.EnterTextIntoSearchBox("Harry Potter and the Philosopher's Stone");
		    amazonHomePage.clickOnSearchButton();
		}

		@Then("^the user verify Harry Potter book is best seller$")
		public void theUserVerifyHarryPotterBookIsBestSeller() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheBestSellerVisibility("Best Seller"));
		}
		
		@Then("^the user verify Harry Potter book is available in Kindle Edition$")
		public void the_user_verify_Harry_Potter_book_is_available_in_Kindle_Edition() throws Throwable {
			Assert.assertTrue(amazonHomePage.userCheckTheKindelVersionVisibility("Harry Potter and the Philosopher's Stone:","Kindle Edition"));
		}


	}
