package com.Amazon.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class DriverFactor {
	
	private WebDriver driver;
	
	private static final String CHROME_PROPERTY = "webdriver.chrome.driver";
			private static final String CHROME_PATH_FILE = "";
			public enum Browsers {
				chrome
			}
			private WebDriver createDriver (Browsers browser){
				if (browser.equals(Browsers.chrome)){
					System.setProperty(CHROME_PROPERTY,CHROME_PATH_FILE);
				}
			return this.driver = new ChromeDriver();
		}
			public WebDriver getDriver(){
				return this.driver;
			}
			public void intDriver(Browsers browser){
              if(this.driver == null){
            	  createDriver(browser);
              }
				}
			public DriverFactor(Browsers browser){
             intDriver(browser);
				}
}


